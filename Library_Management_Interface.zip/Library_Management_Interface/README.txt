LIBRARY MANAGEMENT INTERFACE

Files:
- index.html: webpage structure
- style.css: page styling
- script.js: book management functions

How to run:
1. Keep all three files in the same folder.
2. Open index.html in a web browser.
3. Add a book before trying the Issue Book feature.
4. Use the Book ID shown in the catalogue to issue a book.

Note:
This is a front-end mini-project. Data is stored in the browser's Local Storage.
Clearing browser storage may remove saved records. It does not use a server database.
