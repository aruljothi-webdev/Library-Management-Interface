let books = JSON.parse(localStorage.getItem("libraryBooks") || "[]");
let records = JSON.parse(localStorage.getItem("libraryRecords") || "[]");
let nextId = Math.max(0, ...books.map(book => book.id)) + 1;

function save() {
    localStorage.setItem("libraryBooks", JSON.stringify(books));
    localStorage.setItem("libraryRecords", JSON.stringify(records));
}

function addBook() {
    const title = document.getElementById("title").value.trim();
    const author = document.getElementById("author").value.trim();
    const isbn = document.getElementById("isbn").value.trim();
    const category = document.getElementById("category").value;
    const qtyValue = document.getElementById("qty").value;
    const qty = Number(qtyValue);

    if (!title || !author || !isbn || !category ||
        qtyValue === "" || !Number.isInteger(qty) || qty < 1) {
        alert("Please enter all book details correctly.");
        return;
    }

    if (books.some(book => book.isbn.toLowerCase() === isbn.toLowerCase())) {
        alert("This ISBN already exists.");
        return;
    }

    books.push({
        id: nextId++,
        title,
        author,
        isbn,
        category,
        qty,
        available: qty
    });

    save();
    ["title", "author", "isbn", "qty"].forEach(id => {
        document.getElementById(id).value = "";
    });
    document.getElementById("category").value = "";
    showBooks();
    alert("Book added successfully.");
}

function showBooks() {
    const search = document.getElementById("search").value.toLowerCase().trim();
    const filter = document.getElementById("filter").value;
    const list = document.getElementById("bookList");
    list.innerHTML = "";

    const total = books.reduce((sum, book) => sum + book.qty, 0);
    const available = books.reduce((sum, book) => sum + book.available, 0);

    document.getElementById("total").textContent = total;
    document.getElementById("available").textContent = available;
    document.getElementById("issued").textContent = total - available;

    const filteredBooks = books.filter(book => {
        const matchesSearch = [book.title, book.author, book.isbn]
            .some(value => value.toLowerCase().includes(search));
        const matchesFilter = filter === "All" ||
            (filter === "Available" && book.available > 0) ||
            (filter === "Issued" && book.available < book.qty);
        return matchesSearch && matchesFilter;
    });

    if (filteredBooks.length === 0) {
        list.innerHTML = '<tr><td colspan="8">No books found.</td></tr>';
    }

    filteredBooks.forEach(book => {
        const row = document.createElement("tr");
        row.innerHTML = `
            <td>${book.id}</td>
            <td>${escapeHTML(book.title)}</td>
            <td>${escapeHTML(book.author)}</td>
            <td>${escapeHTML(book.isbn)}</td>
            <td>${escapeHTML(book.category)}</td>
            <td>${book.qty}</td>
            <td>${book.available}</td>
            <td>
                <button onclick="editBook(${book.id})">Edit</button>
                <button class="danger" onclick="deleteBook(${book.id})">Delete</button>
            </td>`;
        list.appendChild(row);
    });

    showRecords();
}

function editBook(id) {
    const book = books.find(item => item.id === id);
    if (!book) return;

    const title = prompt("Book title:", book.title);
    if (title === null) return;
    const author = prompt("Author:", book.author);
    if (author === null) return;
    const category = prompt("Category:", book.category);
    if (category === null) return;

    if (!title.trim() || !author.trim() || !category.trim()) {
        alert("Fields cannot be empty.");
        return;
    }

    book.title = title.trim();
    book.author = author.trim();
    book.category = category.trim();
    save();
    showBooks();
}

function deleteBook(id) {
    if (records.some(record => record.bookId === id)) {
        alert("Return all issued copies before deleting this book.");
        return;
    }

    const book = books.find(item => item.id === id);
    if (book && confirm("Delete " + book.title + "?")) {
        books = books.filter(item => item.id !== id);
        save();
        showBooks();
    }
}

function issueBook() {
    const student = document.getElementById("borrower").value.trim();
    const id = Number(document.getElementById("issueId").value);
    const dueDate = document.getElementById("dueDate").value;
    const book = books.find(item => item.id === id);

    if (!student || !Number.isInteger(id) || !book || !dueDate) {
        alert("Enter a student name, valid Book ID, and due date.");
        return;
    }

    if (book.available < 1) {
        alert("No copies are currently available.");
        return;
    }

    records.push({
        student,
        bookId: id,
        bookTitle: book.title,
        issueDate: new Date().toLocaleDateString(),
        dueDate
    });

    book.available--;
    save();
    document.getElementById("borrower").value = "";
    document.getElementById("issueId").value = "";
    document.getElementById("dueDate").value = "";
    showBooks();
    alert("Book issued successfully.");
}

function returnBook(index) {
    const record = records[index];
    if (!record) return;

    const book = books.find(item => item.id === record.bookId);
    if (book && book.available < book.qty) {
        book.available++;
    }

    records.splice(index, 1);
    save();
    showBooks();
    alert("Book returned successfully.");
}

function showRecords() {
    const list = document.getElementById("issueList");
    list.innerHTML = "";

    if (records.length === 0) {
        list.innerHTML = '<tr><td colspan="5">No issued books.</td></tr>';
        return;
    }

    records.forEach((record, index) => {
        const row = document.createElement("tr");
        row.innerHTML = `
            <td>${escapeHTML(record.student)}</td>
            <td>${escapeHTML(record.bookTitle)} (ID: ${record.bookId})</td>
            <td>${escapeHTML(record.issueDate)}</td>
            <td>${escapeHTML(record.dueDate)}</td>
            <td><button onclick="returnBook(${index})">Return</button></td>`;
        list.appendChild(row);
    });
}

function escapeHTML(value) {
    return String(value).replace(/[&<>"']/g, char => ({
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
        '"': "&quot;",
        "'": "&#39;"
    })[char]);
}

showBooks();
